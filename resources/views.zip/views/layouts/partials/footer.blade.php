{{--<br>--}}
{{--<br>--}}
{{--<br>--}}
{{--<footer style="bottom: 0;--}}
{{--    position: absolute;--}}
{{--    width: 100%;">--}}

{{--<div class="kt-footer kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">--}}
{{--    <div class="kt-footer__copyright">--}}
{{--        2019&nbsp;&copy;&nbsp;<a href="http://keenthemes.com/metronic" target="_blank" class="kt-link">Keenthemes</a>--}}
{{--    </div>--}}
{{--    <div class="kt-footer__menu">--}}
{{--        <a href="http://keenthemes.com/metronic" target="_blank" class="kt-footer__menu-link kt-link">About</a>--}}
{{--        <a href="http://keenthemes.com/metronic" target="_blank" class="kt-footer__menu-link kt-link">Team</a>--}}
{{--        <a href="http://keenthemes.com/metronic" target="_blank" class="kt-footer__menu-link kt-link">Contact</a>--}}
{{--    </div>--}}
{{--</div>--}}
{{--</footer>--}}
