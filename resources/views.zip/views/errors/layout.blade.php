<!DOCTYPE html>
<html lang="en">
    <head>
   @include('.layouts.partials.head')
    </head>
    <body>
                    @yield('content')

        @include('.layouts.partials.scripts')
    </body>
</html>
